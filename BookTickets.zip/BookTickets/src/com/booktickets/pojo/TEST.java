package com.booktickets.pojo;

public class TEST {

	public static void main(String [] args)
	{
	for (int i=1;i>=21;i++)
		{
		for(int j=1;j>=21;i++)
		{
			System.out.println(i+"-"+j);
		}
	}
}
}