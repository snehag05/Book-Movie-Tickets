package com.booktickets.servlet;

public @interface WebServlet {

}
