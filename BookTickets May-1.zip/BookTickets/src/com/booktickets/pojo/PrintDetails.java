package com.booktickets.pojo;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.print.PageFormat;
import java.awt.print.Printable;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.util.Date;

public class PrintDetails implements Printable{

	int transactionID;
	String slot;
	String image;
	String title;
	int screen_no;
	int seat_no;
	int count;
	Date date;
	int price;
	int total;
	 
	public PrintDetails()
	{
		
	}
	public PrintDetails(int transactionID, String slot, String image, String title, int screen_no, int seat_no, int count, Date date, int price, int total) {
		super();
		this.transactionID = transactionID;
		this.slot = slot;
		this.image = image;
		this.title = title;
		this.screen_no = screen_no;
		this.seat_no = seat_no;
		this.count = count;
		this.date = date;
		this.price = price;
		this.total = total;
	}
	
	public int getTransactionID() {
		return transactionID;
	}
	public void setTransactionID(int transactionID) {
		this.transactionID = transactionID;
	}
	public String getSlot() {
		return slot;
	}
	public void setSlot(String slot) {
		this.slot = slot;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	
	public int getScreen_no() {
		return screen_no;
	}
	public void setScreen_no(int screen_no) {
		this.screen_no = screen_no;
	}
	public int getSeat_no() {
		return seat_no;
	}
	public void setSeat_no(int seat_no) {
		this.seat_no = seat_no;
	}
	public int getCount() {
		return count;
	}
	public void setBooked(int count) {
		this.count = count;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getTotal() {
		int total = 0;
		total = price * getCount();
		return total;
	}
	public void setTotal(int total) {
		total = getTotal();
	}
	
	//overriding toString() method
	
	public String toString() {
		return "The transaction "+this.transactionID+" for the date "+this.date+" for the time slot "+this.slot+" with image "+this.image+" is "+this.title+". It will be shown on screen "+this.screen_no
					+". The customer seats are "+this.seat_no+". The cost per ticket is "+this.price+". The customer booked "+this.count+" seats. The total is "+this.total;
	}
	
	
	
	private static Font sFont = new Font("Serif", Font.PLAIN, 64);
	
	@Override
	public int print(Graphics g, PageFormat Pf, int pageIndex) throws PrinterException {
	    if (pageIndex > 0)
	      return NO_SUCH_PAGE;
	    Graphics2D g2 = (Graphics2D) g;
	    g2.setFont(sFont);
	    g2.setPaint(Color.black);
	    g2.drawString("Download ticket", 96, 144);
	    return PAGE_EXISTS;
	  }

	  public static void main(String[] args) {
	    PrinterJob job = PrinterJob.getPrinterJob();
	    job.setPrintable(new PrintDetails());
	    if (job.printDialog()) {
	      try {
	        job.print();
	      } catch (PrinterException e) {
	      }
	    }
	    System.exit(0);
	  }
}
